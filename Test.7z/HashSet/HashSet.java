package hashtable;

import java.util.NoSuchElementException;
import java.util.Iterator;
import java.util.ConcurrentModificationException;
import java.lang.reflect.Array;
import java.util.*;

public class HashSet<E> implements Iterable<E>
{
    private class Entry {
        private E value;
        private Entry next;
        public Entry(E initValue, Entry initNext) {
            value = initValue;
            next = initNext;
        } 
        public void setValue(E value) { this.value = value; } 
        public E getValue() { return value; } 
        public Entry getNext() { return next; } 
        public void setNext(Entry next) { this.next = next; }        
        public String toString() { return value.toString(); }
    }
    
    private static final int CAPACITY = 60;
    private Entry[] table;
    private int size; 

    public HashSet() {
        table = (Entry[]) Array.newInstance(Entry.class,
                CAPACITY);
        size = 0;
    }
    public int size() {
        return size;
    }
    public boolean isEmpty() {
        return size == 0;
    }

    public void add(E value) {
        if (!contains(value))
        { Entry node = new Entry(value, null);
        int index = Math.abs(value.hashCode()) % table.length;

        if (table[index] == null)
            table[index] = node;
        else
        {
            Entry current = table[index];
            while (current.getNext() != null)
                current = current.getNext();
            current.setNext(node);
            size++;
        }
        }
    }
    public boolean contains(E value) {
        int index = Math.abs(value.hashCode()) % table.length;

        Entry node = table[index];
        while (node != null)
        {
            if (node.getValue().equals(value))
                return true;
            node = node.getNext();
        }
        return false;
    }

    public E get(E value) {
        int index = Math.abs(value.hashCode()) % table.length;

        Entry current = table[index];
        while (current != null)
        {
            if (current.getValue().equals(value))
                return value;
            current = current.getNext();
        }
        return null;
    }
    public boolean remove(E value) {
        int index = Math.abs(value.hashCode()) % table.length;

        Entry current = table[index];
//      Entry current = table[i];
        if (current != null)
        {
            if (current.getValue().equals(value))
            {
                table[index] = current.getNext();
                size++;
                return true;
            }
            else   // if (current.getValue().equals(value)) 
            {
                while (current.getNext() != null)
                {
                    E nextValue = current.getNext().getValue();
                    if (nextValue.equals(value))
                    {                 
                        current.setNext(current.getNext().getNext());
                        size--;
                        return true;
                    }
                    current = current.getNext();
                }
            }
        }           
        return false;
    }

    public String toString() {
        String str = "";
        for (int i = 0; i < table.length; i++)
        {
            str += i + ":  ";
            Entry current = table[i];
            while (current != null)
            {
                str += current.getValue();
                if (current.getNext() != null)
                    str += ",  ";
                current = current.getNext();
            }    
            str += "\n";
        }
        return str;
    }
    public Iterator<E> iterator() {
        return new HashTableIterator();
    }
    /*    public void remove() {
          checkForComodification();
          if (last == null)
          throw new IllegalStateException();    
          Entry node = table[lastIndex];
          if (node == last)
          table[lastIndex] = node.getNext();
          else
          {
          while (node.getNext() != last)
          node = node.getNext();
          node.setNext(node.getNext().getNext());    
          }
          size--;
          expectedCount--;
    } 
    private void checkForComodification() {
    if (size != expectedCount)
    throw new ConcurrentModificationException();
    }*/
    private class HashTableIterator implements Iterator<E>
    {
        private int expectedCount;
        private Entry last;
        private Entry next;
        private int index;
        private int lastIndex;
        public HashTableIterator() {
            expectedCount = size;
            index = 0;
            last = null;
            next = null;
            while (index < table.length && table[index] == null)
                index++;
            if (index < table.length)
                next = table[index];
        }
//        @Override
        public Iterator<E> iterator() {
            return new HashTableIterator();
        }
        public boolean hasNext() {
            return next != null;
        }

        public E next() {
            checkForComodification();
            if (next == null)
                throw new NoSuchElementException();

            last = next;
            lastIndex = index;
            next = next.getNext();

            if (next == null)
            {
                do
                {
                    index++;
                }
                while (index < table.length && table[index] == null);
                if (index < table.length)
                    next = table[index];
            }    
            return last.getValue();
        }
//        @Override
        public void remove() {
            checkForComodification();
            if (last == null)
                throw new IllegalStateException();

            Entry node = table[lastIndex];
            if (node == last)
                table[lastIndex] = node.getNext();
            else
            {
                while (node.getNext() != last)
                    node = node.getNext();
                node.setNext(node.getNext().getNext());    
            }
            size--;
            expectedCount--;
        }

        private void checkForComodification() {
            if (size != expectedCount)
                throw new ConcurrentModificationException();
        }
    }
}




