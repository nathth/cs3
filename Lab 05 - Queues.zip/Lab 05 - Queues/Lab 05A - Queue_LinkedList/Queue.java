import *;

public class Queue { 
	
	
}